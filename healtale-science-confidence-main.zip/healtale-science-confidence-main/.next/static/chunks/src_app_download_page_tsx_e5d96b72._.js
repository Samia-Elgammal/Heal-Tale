(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_6019879d._.js",
  "static/chunks/src_5c6af2ae._.js"
],
    source: "dynamic"
});
